# Tracking the Effectiveness of Automation in DevOps

Instructions to run the project.