
import streamlit as st

st.title("Chat Analyzer")
st.write("Upload a chat file and analyze messages...")
