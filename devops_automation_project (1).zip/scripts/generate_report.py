
with open("report.txt", "w") as f:
    f.write("Automation Report\n")
    f.write("Deployment Time: 3.00 seconds\n")
    f.write("Failure Rate: 0%\n")
