
import time

start = time.time()
print("Simulating deployment...")
time.sleep(3)
end = time.time()

print(f"Deployment completed in {end - start:.2f} seconds")
